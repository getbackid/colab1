import tensorflow as tf

#def run_graph(file):


g = tf.Graph()

with g.as_default():
    with tf.name_scope('variables'):
        with tf.name_scope('input'):
            input1 = tf.placeholder(dtype=tf.int32,shape=[None,1],name='input')
            input2 = tf.placeholder(dtype=tf.int32,shape=[None,1],name='input')
            input3 = tf.placeholder(dtype=tf.int32,shape=[None,1],name='input')
            input4 = tf.placeholder(dtype=tf.int32,shape=[None,1],name='input')
            
        with tf.name_scope('imtermediate_layer'):
            imter_layer_prod = tf.reduce_prod(input1,input3, name='prod_input')
            imter_layer_sum = tf.reduce_sum(input1,input3, name='sum_input')
            
        with tf.name_scope('output'):
            const = tf.add(imter_layer_prod,imter_layer_sum, name='total_sum')
            
           
#            
sess = tf.Session(graph=g)
#feed_d = {input1:[2,8], input2:[3,1,3,3],input3:[8],input4:[2,3,7],}
feed_d = {input1:[8], input2:[3],input3:[8],input4:[7]}
_imter_layer_prod,_imter_layer_sum,_const = sess.run([imter_layer_prod,imter_layer_sum,const],feed_dict=feed_d)         


tf.summary.FileWriter('./g_log',graph=g)

