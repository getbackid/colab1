import tensorflow as tf
import numpy as np
#
#  1
#input_data = [1,2,3,4,5]
#
#x=tf.placeholder(dtype=tf.float32)
#y=x*2
#
#sess = tf.Session()
#
#result = sess.run(y,feed_dict={x:input_data})
#
#print(result)

#2
#a=tf.placeholder(dtype=tf.int32, shape=[2,2], name='input_a')
#b=tf.reduce_prod(a, name='prod_b')
#c = tf.reduce_sum(a, name='sum_c')
#
#d=tf.add(b,c, name='add_d')
#
#feed_d={a:np.array([[5,3],[4,7]], dtype=np.int32)}
#
##feed_d={a:tf.constant([[5,3],[4,7]], dtype=np.int32)}
#
#sess=tf.Session()
#_b,_c,_d = sess.run([b,c,d], feed_dict=feed_d)
#print('b:{} c:{} d:{}'.format(_b, _c, _d))
#
##3
#input_data = [1,2,3,4,5]
#x=tf.placeholder(dtype=tf.float32)
#W=tf.Variable([3],dtype=tf.float32)
#y=W*x
#
#sess=tf.Session()
#init = tf.global_variables_initializer()
#sess.run(init)
#result = sess.run(y,feed_dict={x:input_data})
#
#print(result)

##4
#my_var = tf.Variable(1, dtype=tf.int32)
#
#my_var_times_two = tf.assign(my_var,my_var*2)
#
#sess = tf.Session()
#sess.run(tf.global_variables_initializer())
#print(sess.run(my_var_times_two))
#print(sess.run(my_var_times_two))
#print(sess.run(my_var_times_two))

#5

#print(tf.get_default_graph())
#g=tf.Graph()
#print('g gragh:',g)
#
#with g.as_default():
#    b = tf.multiply(3,5, name = 'mul_b')
#    c = tf.add(b,5, name='add_c')
#    d = tf.subtract(c, 7, name='sub_c')
#    
##print(b.graph is g)
#sess = tf.Session(graph=g)
#result = sess.run(d)
#print('result:', result)
#
#tf.summary.FileWriter('./g_log',graph=tf.get_default_graph())
#
#
#
#

#name scope

#with tf.name_scope('Scope_A'):
#    a = tf.add(1,4,name='a_add')
#    b = tf.multiply(a,3,name='a_mul')
#    
#with tf.name_scope('Scop_B'):
#    c = tf.add(4,5,name='b_scop')
#    d = tf.multiply(c,6,name='b_mul')
#    
#print(tf.Session().run(b+d))
#tf.summary.FileWriter('./g_log',graph=tf.get_default_graph())
#    

#
#
#g = tf.Graph()
#with g.as_default():
#    in1 = tf.placeholder(dtype=tf.float32, shape=[None,2],name='input_a')
#    in2 = tf.placeholder(dtype=tf.float32, shape=[None,2],name='input_b')
#    const = tf.constant(2,dtype=tf.float32, name = 'static_value')
#    
#    with tf.name_scope('Transformation'):
#        with tf.name_scope('A'):
#            a_mul = tf.multiply(in1, const)
#            a_out = tf.subtract(a_mul,in1)
#            
#        with tf.name_scope('B'):
#            b_mul = tf.multiply(in2, const)
#            b_out = tf.subtract(b_mul, in2)
#            
#        with tf.name_scope('C'):
#            c_mul = tf.multiply(a_out, b_out)
#            c_out = tf.subtract(c_mul, const)
#            
#        with tf.name_scope('D'):
#            d_div = tf.multiply(b_out, a_out)
#            d_out = tf.subtract(d_div, const)
#    out = tf.maximum(c_out, d_out)
#    
#sess = tf.Session(graph=g)
#feed_d = {in1:[[2,4],[6,4]], in2:[[5,6],[7,1]]}
#_out, _c_out, _d_out = sess.run([out,c_out,d_out],feed_dict=feed_d)         
#
#print('out:{}\nc_out:{}\nd_out:{}'.format(_out, _c_out, _d_out))  
#
#tf.summary.FileWriter('./g_log',graph=g)
#
#            





















