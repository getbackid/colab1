import tensorflow as tf


a = tf.constant(21, dtype = tf.float32)
b = tf.constant(10, dtype = tf.float32)
c = tf.constant(2, dtype = tf.float32)

d= a*b-c
sess=tf.Session()
result = sess.run(d)

print(result)

_a,_b,_c,_d = sess.run(fetches=[a,b,c,d])

e=tf.multiply(a,b,name='mul')
f=tf.subtract(e,c,name='sub')
result2 = sess.run(f)

tf.summary.FileWriter('./g_log',sess.graph)