import tensorflow as tf

a = tf.constant([5,3], name='input_a')
b = tf.reduce_prod(a, name='prod_d')
c = tf.reduce_sum(a, name='sum_c')
d = tf.add(b,c,name='add_d')

sess = tf.Session()
result = sess.run(d)
print(result)

x = tf.constant([1,2,3], dtype=tf.float64)
print(x.dtype)
x=tf.cast(x, dtype=tf.int32)
print(x.dtype)

