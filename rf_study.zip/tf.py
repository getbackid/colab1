import tensorflow as tf

g = tf.Graph()
with g.as_default():
    in1 = tf.placeholder(dtype=tf.float32, shape=[None,2],name='input_a')
    in2 = tf.placeholder(dtype=tf.float32, shape=[None,2],name='input_b')
    const = tf.constant(2,dtype=tf.float32, name = 'static_value')
    
    with tf.name_scope('Transformation'):
        with tf.name_scope('AA'):
            a_mul = tf.multiply(in1, const)
            a_out = tf.subtract(a_mul,in1)
            
        with tf.name_scope('B'):
            b_mul = tf.multiply(in2, const)
            b_out = tf.subtract(b_mul, in2)
            
        with tf.name_scope('C'):
            c_mul = tf.multiply(a_out, b_out)
            c_out = tf.subtract(c_mul, const)
            
        with tf.name_scope('D'):
            d_div = tf.multiply(b_out, a_out)
            d_out = tf.subtract(d_div, const)
    out = tf.maximum(c_out, d_out)
    
sess = tf.Session(graph=g)
feed_d = {in1:[[2,4],[6,4]], in2:[[5,6],[7,1]]}
_out, _c_out, _d_out = sess.run([out,c_out,d_out],feed_dict=feed_d)         

print('out:{}\nc_out:{}\nd_out:{}'.format(_out, _c_out, _d_out))  

tf.summary.FileWriter('./g_log',graph=g)

            