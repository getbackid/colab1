import tensor as tf
import pandas as pd
import numpy as np
import os
from PIL import ImageTk, Image



#from PIL import ImageTk,Image


os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

ds = pd.Series(np.array(20))
print(ds)
tf.InteractiveSession()
a = tf.constant(23)
print(a.eval())